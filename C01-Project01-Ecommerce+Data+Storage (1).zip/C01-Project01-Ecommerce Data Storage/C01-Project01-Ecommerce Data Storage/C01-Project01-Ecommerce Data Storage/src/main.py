import mysql.connector
# Driver code
if __name__ == "__main__":
  """
    Please enter the necessary information related to the DB at this place. 
    Please change PW and ROOT based on the configuration of your own system. 
    """

#
#mysql new table creation sting
create_customer_leaderboard_table = """
    create table if not exists customer_leaderboard(
        customer_id varchar(10) primary key,
        total_value double not null,
        customer_name varchar(50) not null,
        customer_email varchar(50) not null

    )
    """


#connecttion to mysql as mydb

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password = "N#@98wrft45",
 database = "ecommerce_record"
)
# DELECT DATA FROM TABLES BEFORE RUN THIS MAIN  ( delete FROM ecommerce_record.orders where order_id IN (101,102,103,104,105); delete FROM ecommerce_record.customer_leaderboard
# where customer_id ='10';)

#mydb = mysql.connector.connect(  LOCALHOST = "localhost", PW = "admin@123",   ROOT = "root",  DB = "ecommerce_record")

## main code



# IN SERT Order Table 2.B
cur = mydb.cursor()
sql = """ INSERT INTO orders (order_id,customer_id,vendor_id,total_value,order_quantity,reward_point) values (%s, %s, %s, %s, %s, %s)  """
val = [
    ("101", "11", "5", "16807", "6", "300"),
    ("102", "12", "6", "16808", "7", "400"),
    ("103", "13", "7", "16808", "8", "500"),
    ("104", "11", "8", "16809", "9", "600"),
    ("105", "11", "9", "168090", "10", "700")
]
cur.executemany(sql, val)
mydb.commit()

## show data from order table 2.C

cur = mydb.cursor()
cur.execute("SELECT * FROM orders")
result = cur.fetchall()
for i in result:
    print(i)
# Problem Statement (Hard)  3.A
#Find Min and Max values in orders Table

print("Find Min and Max values in orders")
cur = mydb.cursor()
sql = "SELECT  MAX(total_value ) ,MIN(total_value )  as total_value  FROM `orders`"
cur.execute(sql)
result = cur.fetchall()
for rec in result:
    print(rec)
mydb.commit()



# Problem Statement (Hard)  3.B
print("Find avarage")


cur = mydb.cursor()
sql = "SELECT AVG(total_value ) FROM `orders`"
cur.execute(sql)
result = cur.fetchall()
for rec in result:
    print(rec)
    mt_avg_tt = rec
mydb.commit()

#Fetch and print the orders with value (total_value) greater than the average value (total_value)
#of all the orders in the orders table
print("total_value greater than the average value")
cur = mydb.cursor()

sql1 = "SELECT   *  FROM `orders` WHERE total_value > (select avg(total_value) from ecommerce_record.orders) "
#
cur.execute(sql1)
result = cur.fetchall()
for rec in result:
    print(rec)
mydb.commit()



# Problem Statement (Hard)  3.C
# creation of a new table in the name of customer_leaderboard is not exists
cur = mydb.cursor()
cur.execute(create_customer_leaderboard_table)
print("customer_leaderboard ois created or exists ")
# need to delet any data is already in the table [ delete FROM ecommerce_record.customer_leaderboard where customer_id ='10';]

#Insert one row for each registered customer who has made a purchase
cur = mydb.cursor()
sql1 = "SELECT  users.user_id, max(orders.total_value) as MaxTotal,  users.user_name, users.user_email \
FROM orders \
INNER JOIN users \
ON orders.customer_id = users.user_id "
cur.execute(sql1)
result = cur.fetchall()
cur.executemany("insert into customer_leaderboard (customer_id, total_value, customer_name,customer_email) values (%s,%s,%s,%s);", result)
for rec in result:
 print(rec)
mydb.commit()