import mysql.connector

# ecom_creation of Database
mydb = mysql.connector.connect(  host="localhost",
                                  user="root",
                                  password = "N#@98wrft45",
                                  database = "ecommerce_record")

#mydb = mysql.connector.connect( LOCALHOST = "localhost", PW = "admin@123",   ROOT = "root",  DB = "ecommerce_record")

cur = mydb.cursor()
cur.execute("CREATE DATABASE if not exists ecommerce_record")
mydb.commit()

