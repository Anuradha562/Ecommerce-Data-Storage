import database as db
import mysql.connector
# Driver code

# MySql connection strings for table creation
create_users_table = """
    create table if not exists users(
        user_id varchar(10) primary key,
        user_name varchar(45) not null,
        user_email varchar(45) not null,
        user_password varchar(45) not null,
        user_address varchar(45) null,
        is_vendor tinyint(1) default 0
    )
    """
create_products_table = """
    create table if not exists products(
        product_id varchar(45) primary key,
        product_name varchar(45) not null,
        product_price double not null,
        product_description varchar(10) not null,
        vendor_id varchar(10) not null,
        emi_available varchar(10) not null,
        CONSTRAINT `vendor_id`
        FOREIGN KEY (`vendor_id`)
        REFERENCES `ecommerce_record`.`users` (`user_id`)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION
    )
    """

create_orders_table = """
    create table if not exists orders(
        order_id int primary key,
        customer_id varchar(10) not null,
        vendor_id varchar(10) not null,
        total_value double not null,
        order_quantity int not null,
        reward_point int not null,
        FOREIGN KEY (`vendor_id`)
        REFERENCES `ecommerce_record`.`users` (`user_id`)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION,
        CONSTRAINT `customer_id`
        FOREIGN KEY (`customer_id`)
        REFERENCES `ecommerce_record`.`users` (`user_id`)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION
    )
    """

# MySql connection strings for table creation

# ecom_DBUSER_11

mydb = mysql.connector.connect(  host="localhost",
                                 user="root",
                                 password = "N#@98wrft45",
                                 database = "ecommerce_record")

#mydb = mysql.connector.connect(  LOCALHOST = "localhost", PW = "admin@123",   ROOT = "root",  DB = "ecommerce_record")

cur = mydb.cursor()
# creating if not exists users
cur.execute(create_users_table)
# creating if not exists prod
cur.execute(create_products_table)
# creating if not exists order
cur.execute(create_orders_table)
mydb.commit()
print("Allb Tables Created")

# SHOW TABLE DATA OF ORDERS
cur = mydb.cursor()
cur.execute("SELECT * FROM orders")
result = cur.fetchall()
for i in result:
    print(i)

    # SHOW TABLE DATA OF users
    cur = mydb.cursor()
    cur.execute("SELECT * FROM users")
    result = cur.fetchall()
    for i in result:
        print(i)

# SHOW TABLE DATA OF PRODUCTS
    cur = mydb.cursor()
    cur.execute("SELECT * FROM products")
    result = cur.fetchall()
    for i in result:
        print(i)

mydb.commit()




